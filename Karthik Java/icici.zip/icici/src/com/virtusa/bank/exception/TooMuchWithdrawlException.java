package com.virtusa.bank.exception;

public class TooMuchWithdrawlException extends Exception {

	public TooMuchWithdrawlException(String string) {
		// TODO Auto-generated constructor stub
	}

	public TooMuchWithdrawlException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TooMuchWithdrawlException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TooMuchWithdrawlException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TooMuchWithdrawlException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
