package com.virtusa.facebook.exception;

public class TooMuchDataException {

}
