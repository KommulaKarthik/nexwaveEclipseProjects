package com.virtusa.travel_line.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.model.AdminDetail;
import com.virtusa.travel_line.model.FeedbackDetail;
import com.virtusa.travel_line.model.ServiceDetail;
import com.virtusa.travel_line.service.IAdmin;


public class AdminDao implements IAdmin {

	public AdminDao() {
		// TODO Auto-generated constructor stub
	}
	
	
	Logger logger = Logger.getLogger("AdminDao");

	@Override
	public String addService(AdminDetail adminDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		
		String str="";
		
		
		
		
		return str;
	}

	@Override
	public String modifyService(AdminDetail adminDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addAdmin(AdminDetail adminDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteService(AdminDetail adminDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FeedbackDetail viewFeedback(FeedbackDetail feedbackDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceDetail viewSchedules(ServiceDetail serviceDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doLogin(AdminDetail adminDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		int flag = 0;
		Connection connection = com.virtusa.travel_line.util.ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection
					.prepareStatement(" ");
			preparedStatement.setString(1, adminDetail.getAdminName());

			preparedStatement.setString(2, adminDetail.getPassword());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("error with SQL", e);
			throw new TravelLineException("Some internal error contact to admin");
		} catch (Exception exception) {

			logger.error("error with system", exception);
			throw new TravelLineException("Some internal error contact to admin");

		}

		finally {

			// close pstmt,connection,result set also
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO: handle exception
				throw new TravelLineException(" error while closing a resource ");

			}

		}
		return flag;
	}

}
