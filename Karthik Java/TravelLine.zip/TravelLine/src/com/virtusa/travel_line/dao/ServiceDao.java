package com.virtusa.travel_line.dao;

import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.model.ServiceDetail;
import com.virtusa.travel_line.service.IService;

public class ServiceDao implements IService {

	public ServiceDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printServiceDetails() throws TravelLineException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServiceDetail searchService(ServiceDetail serviceDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceDetail selectService(ServiceDetail serviceDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

}
