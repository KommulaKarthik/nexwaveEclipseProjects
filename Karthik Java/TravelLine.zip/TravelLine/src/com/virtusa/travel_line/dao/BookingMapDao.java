package com.virtusa.travel_line.dao;

import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.model.BookingMapDetail;
import com.virtusa.travel_line.service.IBookingMap;

public class BookingMapDao implements IBookingMap {

	public BookingMapDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void displayBookingDetails(BookingMapDetail bookingMapDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectSeat(BookingMapDetail bookingMapDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		
	}

}
