package com.virtusa.travel_line.dao;

import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.model.ServiceDetail;
import com.virtusa.travel_line.service.ICustomer;

public class CustomerDao implements ICustomer {

	public CustomerDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public ServiceDetail retrieveTicket(ServiceDetail serviceDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

}
