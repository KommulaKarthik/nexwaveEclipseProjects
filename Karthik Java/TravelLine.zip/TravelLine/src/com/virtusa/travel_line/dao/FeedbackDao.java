package com.virtusa.travel_line.dao;

import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.service.IFeedback;

public class FeedbackDao implements IFeedback {

	public FeedbackDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String feedback() throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cancelFeedback() throws TravelLineException {
		// TODO Auto-generated method stub
		return null;
	}

}
