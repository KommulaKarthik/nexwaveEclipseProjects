package com.virtusa.travel_line.service;

import com.virtusa.travel_line.dao.BookingMapDao;
import com.virtusa.travel_line.exception.TravelLineException;
import com.virtusa.travel_line.model.BookingMapDetail;

public class BookingMapService {

	public BookingMapService() {
		// TODO Auto-generated constructor stub
		
		
	}
	private BookingMapDao bookingMapDao = new BookingMapDao();
	
	
	public void displayBookingDetails(BookingMapDetail bookingMapDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		
	}

	
	public void selectSeat(BookingMapDetail bookingMapDetail) throws TravelLineException {
		// TODO Auto-generated method stub
		
	}

}
