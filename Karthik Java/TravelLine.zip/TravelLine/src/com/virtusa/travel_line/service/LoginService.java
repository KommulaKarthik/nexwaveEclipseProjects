package com.virtusa.travel_line.service;

public class LoginService {

	public LoginService() {
		// TODO Auto-generated constructor stub
	}

}
