package com.virtusa.travel_line.service;

public class PaymentService {

	public PaymentService() {
		// TODO Auto-generated constructor stub
	}

}
