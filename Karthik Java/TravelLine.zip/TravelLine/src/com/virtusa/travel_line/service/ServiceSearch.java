package com.virtusa.travel_line.service;

public class ServiceSearch {

	public ServiceSearch() {
		// TODO Auto-generated constructor stub
	}

}
