package com.virtusa.travel_line.exception;

public class TravelLineException extends Exception {

	public TravelLineException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public TravelLineException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TravelLineException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TravelLineException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TravelLineException() {
		// TODO Auto-generated constructor stub
	}

}
